'use strict';
module.exports = function(app) {
    var product = require('../Controller/productController');
    app.route('/Products')
        .get(product.products)
        .post(product.add);
    app.route('/Products/:productID')
       // .get(product.getproduct)
        .put(product.update)
        .delete(product.delete);
};
